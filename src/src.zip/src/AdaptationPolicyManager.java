import java.util.ArrayList;

public class AdaptationPolicyManager {
    ArrayList<Element> listPolicies = new ArrayList<Element>();
    public AdaptationPolicyManager(){
    }

    public ArrayList<Element> tickPolicies(House house){
        for(Room room : house.roomMap){
            if(Math.abs(room.temperature -GlobalVariables.goalTemperature) < 2.0){
                System.out.println("cond");
                Element elt = new Element(new ValuePriority(Priority.MEDIUM), PolicyName.MIDHEATING,room.name,1);
                addElement(elt,listPolicies);
            }
            else if(room.temperature -GlobalVariables.goalTemperature > 3.0 && room.thermalRadiator.isOn&& room.passivePump.power<=0){
                System.out.println("cond");
                Element elt = new Element(new ValuePriority(Priority.HIGH), PolicyName.OFFHEATING,room.name,1);
                addElement(elt,listPolicies);
            }
            if(room.temperature -GlobalVariables.goalTemperature > 3.0 && !room.electricCooler.isOn && room.passivePump.power>=0){
                System.out.println("cond");
                Element elt = new Element(new ValuePriority(Priority.MEDIUM), PolicyName.MIDCOOLING, room.name,1);
                addElement(elt,listPolicies);
            }
            /*
            if(room.temperature -GlobalVariables.goalTemperature < 1.0 && room.heatingPump.isOn ){
                System.out.println("cond");
                Element elt = new Element(Priority.MEDIUM, PolicyName.OFFCOOLING);
                addElement(elt,listPolicies);
            }
            if(room.temperature - GlobalVariables.goalTemperature >10.0 && !room.heatingPump.isOn){
                System.out.println("cond");
                Element elt = new Element(Priority.HIGH, PolicyName.FULLCOOLING);
                addElement(elt,listPolicies);
            }*/
        }
        return  listPolicies;
    }
    public void addElement(Element elt, ArrayList<Element> list){
        System.out.println("is empty " +list.isEmpty());
        if(list.isEmpty()) list.add(elt);
        else{
            if(! list.contains(elt)){
               int i=0;
               while(elt.priority.average<list.get(i).priority.average) i++;
               if(i<list.size()) list.add(i,elt);
               else list.add(elt);
            }
            else{
                int i=0;
                while(!elt.equals(list.get(i))) i++;
                double av = ((elt.priority.average+list.get(i).priority.average*list.get(i).occurences)/(1+list.get(i).occurences));
                list.get(i).occurences++;
                //average value depends on existing occurences and value of new element
                System.out.println("elt av " + elt.priority.average + " lsit av " + list.get(i).priority.average + " list occ " + list.get(i).occurences );
                list.get(i).priority.average=av;
            }
        }
    }

    public String toString(){
        System.out.print("tostring");
        String ret= " elt list ";
        for(Element elt : listPolicies){
            ret +=elt +" ";
        }
        return ret;
    }
}
