/**
 * Hello world!
 *
 */
import nz.ac.waikato.modeljunit.FsmModel;

import java.util.ArrayList;
import java.util.HashSet;

public class App
{
    public static void main( String[] args )
    {   // TODO : gestion panneaux photo voltaique
        Logger log = new Logger();
        ThermalRadiator r1 =new ThermalRadiator(100.0, 5000, true);
        HeatingPump heatingPump = new HeatingPump(100,1000,4,false);
        Room salon= new Room("Salon",283.15,273.15,30, 0.32,r1, heatingPump);

        ThermalRadiator r2=new ThermalRadiator(100.0, 5000, true);
        Room chambre= new Room("Chambre",283.15,273.15,30, 0.32,r1, null);

        HashSet<Room> rooms = new HashSet<Room>();
        rooms.add(salon);
        rooms.add(chambre);
        Simulator simulator = new Simulator();
        AdaptationPolicyManager apm = new AdaptationPolicyManager();

        House house = new House(273.0,simulator,rooms, apm,heatingPump);
        FsmModel fsm = new EventFSM(house);
        StochasticTester st = new StochasticTester(fsm,house);
        st.generate();

       /* for(int i =0; i<10; i++){
            log.printTemperature(simulator.calculateNewTemperature(i,60));
        }
        simulator.livingRoomRadiator.power=0;
        for(int i =0; i<10; i++){
            log.printTemperature(simulator.calculateNewTemperature(i,60));
        }
        simulator.livingRoomRadiator.power=-1000;
        for(int i =0; i<10; i++){
            log.printTemperature(simulator.calculateNewTemperature(i,60));
        }*/
      //  r1.setHeatingTemperature(room.getTemperature());
        //System.out.println("init " + room.initialTemperature + " actual " +room.temperature);
        //room.switchRadiator();

       /* for(int i =0; i<10; i++){
            System.out.println( "t"+i+": "+simulator.calculateNewTemperature(5.0)+ "\n");
        }*/
       log.closeFile();
    }


}
