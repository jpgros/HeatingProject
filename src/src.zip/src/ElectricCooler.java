public class ElectricCooler extends TemperatureDevice {
    HomeBattery homeBattery;
    public ElectricCooler(double energyCons,double power, boolean on){
        super(energyCons, power, on);
    }
}