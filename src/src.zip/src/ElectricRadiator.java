public class ElectricRadiator extends TemperatureDevice {
    HomeBattery homeBattery;
    public ElectricRadiator(double energyCons,double power, boolean on){
        super(energyCons, power, on);
    }
}
