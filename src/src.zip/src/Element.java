import java.util.Objects;

public class Element {
    ValuePriority priority;
    PolicyName policyname;
    String roomName;
    int occurences;
    public Element(ValuePriority p, PolicyName pn, String rn, int occ){
        priority = p;
        policyname= pn;
        roomName =rn;
        occurences=occ;
    }
    @Override
    public int hashCode() {
        return Objects.hash(policyname, priority);
    }
    @Override
    public boolean equals(Object obj) {
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        Element elt = (Element) obj;
        if (this.policyname == elt.policyname && this.policyname== elt.policyname) { //
            return true;
        }
        else {
            return false;
        }
    }
}
enum  PolicyName{
    FULLHEATING(1,1.0), MIDHEATING(1,GlobalVariables.midHeating/GlobalVariables.fullHeating), OFFHEATING(1,0.0),
    FULLCOOLING(-1,1.0), MIDCOOLING(-1,GlobalVariables.midCooling/GlobalVariables.fullCooling), OFFCOOLING(-1,0.0);
    final int evolution;
    final double percentage;
    private PolicyName(int evo,Double per){
        evolution=evo;
        percentage=per;
    }
}
class ValuePriority{
    Priority priority;
    double average;
    public ValuePriority(Priority p){
        priority =p;
        average=p.value;
    }
}
 enum Priority {

    HIGH(GlobalVariables.high), MEDIUM(GlobalVariables.med), LOW(GlobalVariables.low);
    final double value;

    private Priority(double val) {
        value=val;
    }
}