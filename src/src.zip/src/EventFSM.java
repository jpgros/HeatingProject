import nz.ac.waikato.modeljunit.*;

import nz.ac.waikato.modeljunit.Action;
import nz.ac.waikato.modeljunit.FsmModel;
import java.lang.annotation.Annotation;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.rmi.server.UID;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.UUID;

import com.sun.tools.internal.ws.resources.GeneratorMessages;
public class EventFSM implements FsmModel {
    House house;

    public EventFSM(House h) {
        this.house=h;
    }

    public boolean tickGuard() {
        return true;
    }
    public double tickProba(){ return 0.75;}
    @Action
    public Object[] tick(ArrayList<Object> empty) {
        System.out.println("tick");
        house.tick();
        return new Object[]{ house};
    }

    public boolean newHumanGuard() { return true; }
    public double newHumanProba() { return 0.049999;}
    @Action
    public Object[] newHuman(ArrayList<Object> empty) {
        System.out.println("new human");
        house.setNumberOfhumans(house.getNumberOfhumans()+1);
        return new Object[]{house};
    }

    public boolean humanLeavingGuard() { return house.getNumberOfhumans() == 0 ? false : true; }
    public double humanLeavingProba() { return 0.05;}
    @Action
    public Object[] humanLeaving(ArrayList<Object> empty) {
        System.out.println("human leaving");
        house.setNumberOfhumans(house.getNumberOfhumans()-1);
        return new Object[]{house};
    }


    public boolean cloudyTriggerGuard() {return house.weater == Weather.CLOUDY ?  false :true; }
    public double cloudyTriggerProba() { return 0.05;}
    @Action
    public Object[] cloudyTrigger(ArrayList<Object> empty) {
        System.out.println("cloudy");
        house.setExternalTemperature(263);
        return new Object[]{house};
    }

    public boolean sunnyTriggerGuard() { return house.weater == Weather.SUNNY ?  false :true; }
    public double sunnyTriggerProba() { return 0.05;}
    @Action
    public Object[] sunnyTrigger(ArrayList<Object> empty) {
        System.out.println("sunny");
        house.setExternalTemperature(283);
        return new Object[]{house};
    }

    public boolean rainTriggerGuard() {return house.weater == Weather.RAIN ?  false :true; }
    public double rainTriggerProba() { return 0.05;}
    @Action
    public Object[] rainTrigger(ArrayList<Object> empty) {
        System.out.println("rain");
        //house.setExternalTemperature(283);
        return new Object[]{house};
    }


    @Override
    public Object getState() {
        return null;
    }

    @Override
    public void reset(boolean b) {

    }
}
