public class GlobalVariables {
    public static int timeStep =60;
    public static double maxDeltaTmp=0.1;
    public static double goalTemperature =273.0+20.0;
    public static double electricRadiatorEff = 0.8;
    public static double midCooling = -0.25;
    public static double midHeating = 0.25;
    public static double fullCooling = -1.0;
    public static double fullHeating = 1.0;

    public static double powerRoom = 1000.0;
    public static double powerSalon=4000.0;
    public static String mainRoom = "Salon";
    public static double high = 7.0;
    public static double med = 5.0;
    public static double low = 3.0;
    public static double solarPannelPower = 300; // 300 watt crete at maximum efficiency (sunny climate)
}
