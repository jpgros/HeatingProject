public class HeatingPump extends TemperatureDevice {
    double efficiency;
    double coolingPower;
    PumpStatus status;
    public HeatingPump(double energyCons, double power, double eff, boolean isOn){
        super(energyCons, power, isOn);
        efficiency= eff;
        coolingPower= (efficiency-1)*power; // for each watt of power, 3 watts of cooling and 4 (3 cooling + 1 power) watts of heating
        status=PumpStatus.OFF;
    }
    public void testVar(){
        System.out.println(power);
        System.out.println(isOn);
    }
    public void setPower(double a){
        power=a;
    }
    public void setIsOn(boolean on){
        isOn=on;
    }
    public boolean getIsOn(){
        return isOn;
    }
}

enum PumpStatus { HEATING, COOLING, OFF}
