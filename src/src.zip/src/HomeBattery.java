public class HomeBattery {

}
