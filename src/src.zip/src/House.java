import java.util.HashMap;
import java.util.HashSet;

public class House {
    double externalTemperature = 273; //kelvin}
    AdaptationPolicyManager apm;
    Simulator simulator;
    Weather weater;
    boolean nightMode =false;
    double timeStep= GlobalVariables.timeStep;
    double numberOfhumans = 0;
    int stepNb=0;
    int nbSolarPannel=10;
    HeatingPump heatingPump;
    HashMap<String, Double> outputPercentage = new HashMap<String, Double>();

    HashSet<Room> roomMap;
    public House(double externalTemperature, Simulator s, HashSet<Room> rooms, AdaptationPolicyManager _apm, HeatingPump ep) {
        this.externalTemperature = externalTemperature;
        this.simulator = s;
        weater= Weather.SUNNY;
        roomMap=rooms;
        apm=_apm;
        heatingPump=ep;
        for(Room r : roomMap){
            outputPercentage.put(r.name,0.0);
        }
        outputPercentage.put("Salon",1.0);
    }
   /* public double ratioMainRoom(String elt) {
        if(!elt.equals(GlobalVariables.mainRoom)) {
            return GlobalVariables.powerRoom / GlobalVariables.powerSalon;
        }
        else return 1.0;
    }*/
    public void setExternalTemperature(double externalTemperature) {
        this.externalTemperature = externalTemperature;
    }
    public void tick(){
        //System.out.println("external temperature is " + this.externalTemperature);
        //System.out.println("nb of humans " + this.numberOfhumans);
        for(Element elt : apm.listPolicies){
            System.out.println(" policy " + elt.policyname);
        }

        apm.listPolicies.clear();
        apm.tickPolicies(this);
        System.out.println(apm.toString());

        if(nightMode){
            externalTemperature--;
        }
        else{
            externalTemperature++;
        }
        HashMap<String,Element> eltMap = new HashMap<String,Element>();

        for(Room room : roomMap) { //get first rule of each room to study the heating share
            if (!apm.listPolicies.isEmpty()) {
                eltMap.put(apm.listPolicies.get(0).roomName,apm.listPolicies.get(0));
            }
        }
        Element mainElt = eltMap.get(GlobalVariables.mainRoom);
        double accPower=0.0;
        for(HashMap.Entry<String,Element> eltLoop : eltMap.entrySet()){
            if(eltLoop.getValue().policyname.evolution== mainElt.policyname.evolution) { // if room wants to evolve temperature same as salon
                accPower += (eltLoop.getValue().policyname.percentage); //*ratioMainRoom(eltLoop.getValue().roomName); no ratio we calculate if heating pump is capable of giving the energy
            }
        }
        if(accPower<= GlobalVariables.powerSalon){ // if power is enough we apply the required modifications
                                                    // PEF : increase use of this power
            for(Room room : roomMap) {
                Element eltLoop = eltMap.get(room.name);
                if(mainElt.policyname.evolution>0) {
                    switch (eltLoop.policyname) {
                        case FULLHEATING:
                            System.out.println("trigerfullheat");
                            room.passivePump.power = passivePump(room, GlobalVariables.fullHeating);
                            room.thermalRadiator.isOn = true;
                            break;
                        case MIDHEATING:
                            System.out.println("triger midheat");
                            room.passivePump.power = passivePump(room, GlobalVariables.midHeating);
                            room.thermalRadiator.isOn = true;
                            break;
                        case OFFHEATING:
                            System.out.println("triger offheat");
                            room.thermalRadiator.isOn = false;
                            break;
                        default:
                            System.out.println("Error policy name not taken care of");
                            break;
                    }
                }
                else{
                    switch(eltLoop.policyname){
                        case MIDCOOLING:
                            System.out.println("triger midcool");
                            room.passivePump.power=passivePump(room,GlobalVariables.midCooling);
                            break;

                        case FULLCOOLING:
                            System.out.println("triger fullcool");
                            room.passivePump.power= passivePump(room,GlobalVariables.fullCooling);
                            break;

                        case OFFCOOLING:
                            System.out.println("triger offcool");
                            room.passivePump.power= passivePump(room,GlobalVariables.fullCooling);
                            break;

                        default:
                            System.out.println("Error policy name not taken care of");
                            break;
                    }

                }
            }

        }
        else { // else each room is using its internal heating
            for(Room room : roomMap) {
                Element eltLoop = eltMap.get(room.name);
                switch (eltLoop.policyname) {
                    case FULLHEATING:
                        System.out.println("trigerfullheat");
                        room.thermalRadiator.power = GlobalVariables.fullHeating;
                        room.thermalRadiator.isOn = true;
                        break;
                    case MIDHEATING:
                        System.out.println("triger midheat");
                        room.thermalRadiator.power = GlobalVariables.midHeating;
                        break;
                    case OFFHEATING:
                        System.out.println("triger offheat");
                        room.thermalRadiator.isOn = false;
                        break;
                    default:
                        System.out.println("Error policy name not taken care of");
                        break;
                }
            }

        }
        for(Room room : roomMap) {
            simulator.calculateNewTemperature(stepNb, timeStep, externalTemperature, room);
        }
        simulator.addSolarEnergy(nbSolarPannel,weater);
        stepNb++;
//prendre la valeur du salon et ensuite accumuler les valeurs des chambres dans le meme sens
//        Si l accumulation est inferieure a la puissance maxi on applique sinon on met le salon en priorite et ensuite les autres chambres.
        //TODO threshold value
    }
    public double passivePump(Room room, double power){
        return power*GlobalVariables.powerSalon;
    }
    public void setNumberOfhumans(double numberOfhumans) {
        this.numberOfhumans = numberOfhumans;
    }
    public double getNumberOfhumans() {
        return numberOfhumans;
    }
    public void setNightMode(boolean nightMode) {
        this.nightMode = nightMode;
    }

}
