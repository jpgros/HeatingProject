import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class Logger {
    FileWriter file;
    public Logger(){
        try {
           file = new FileWriter("temperature.csv");
        } catch (IOException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }
    }
    public void printTemperature(double temp){
        try {
            file.write(temp+";");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public void closeFile(){
        try {
            file.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


}
