public interface PropertyAutomaton<House> {
    public String name=null;
    //public int getState();
    public String toString();
    //public void reset();
    public double match(House o) throws PropertyFailedException;
    //public PolicyName getName();
    //public void setName(PolicyName s);
}

abstract class HeatingProperty implements PropertyAutomaton<House> {
        @Override
        public abstract double match(House sut) throws PropertyFailedException;
    }

class PropertyFailedException extends Exception {

    PropertyAutomaton<House> pa;

    public PropertyFailedException(PropertyAutomaton<House> _pa, String msg) {
        super(msg);
        pa = _pa;
    }

}
class BehaviorException extends Exception {
    public BehaviorException(String msg) {
        super(msg);
    }
}

class PropertyCoveredException extends Exception {
    public PropertyCoveredException( String msg) {
        super(msg);
    }
}
class Property1 extends HeatingProperty {
    public double match(House sut) throws PropertyFailedException {
        for(Room room : sut.roomMap){
            if(room.temperature < 280) throw new PropertyFailedException(this, "Temperature too low " + room.temperature);
        }
        return 0;
    }
    public String toString(){
        return "Property1";
    }
}

class Property2 extends HeatingProperty{
    double temperatureMin = 273+16;
    double temperatureMax = 273+30;
    Triple triple;
    public double match(House sut) throws PropertyFailedException {
        for(Room room :sut.roomMap) {
            if (triple == null) {
                triple = new Triple(0, "init", 0);
            }
            switch (triple.state) {
                case 0: //init state
                    if(sut.numberOfhumans >0 ){
                        triple.state=1;
                        triple.transition="humans entered room";
                    }
                    break;

                case 1: // human in room

                    if(sut.numberOfhumans <=0 ){
                        triple.state=2;
                        triple.transition="humans exited room";
                    }
                    else if( room.temperature <temperatureMin  ){
                        throw new PropertyFailedException(this, "Temperature too low for a human" + room.temperature);
                    }
                    else if(room.temperature >temperatureMax){
                        throw new PropertyFailedException(this, "Temperature too high for a human" + room.temperature);
                    }
                    break;
                case 2 :
                    if(sut.numberOfhumans >0 ){// no human in room
                        triple.state=1;
                        triple.transition="humans entered room";
                        System.out.println("humans entered room prop2");
                    }
                    break;

                    default:
                        System.out.println("Error Property 2 default state");
                        break;
            }
        }
        return 0;
    }
    public String toString(){
        return "Property2";
    }
}

class Property3 extends HeatingProperty{
    Triple triple;
    public double match(House sut) throws PropertyFailedException {
        for(Room room :sut.roomMap) {
            if (triple == null) {
                triple = new Triple(0, "init", 0);
            }
            switch (triple.state) {
                case 0: //init
                    if(sut.numberOfhumans >0 ){
                        triple.state=1;
                        triple.transition="humans entered room prop3";
                    }
                    break;

                case 1: // human in room
                    if(sut.numberOfhumans <=0 ){
                        triple.state=2;
                        triple.transition="humans exited room";
                    }
                    else if( Math.abs(room.temperature -room.previousTemperature) > GlobalVariables.maxDeltaTmp  ){
                        throw new PropertyFailedException(this, "Temperature is changing too quickly" +  Math.abs(room.temperature -room.previousTemperature));
                    }
                    break;
                case 2 : //no human in room
                    System.out.println("case 2 prop3");
                    if(sut.numberOfhumans >0 ){
                        triple.state=1;
                        triple.transition="humans entered room ";
                    }
                    break;

                default:
                    System.out.println("Error Property 3 default state");
                    break;
            }
        }
        return 0;
    }
    public String toString(){
        return "Property3";
    }
}

class Property4 extends HeatingProperty{
    Triple triple;
    public double match(House sut) throws PropertyFailedException {
        for(Room room :sut.roomMap) {
            if (triple == null) {
                triple = new Triple(0, "init", 0);
            }
            switch (triple.state) {
                case 0: //init

                    if(room.thermalRadiator.isOn || room.passivePump.power>0){
                        triple.state=1;
                        triple.transition="radiatorOn";
                    }
                    else if (room.electricCooler.isOn || room.passivePump.power <0){
                        triple.state=3;
                        triple.transition="coolerOn";
                    }
                    if((room.thermalRadiator.isOn || room.passivePump.power>0) && (room.electricCooler.isOn || room.passivePump.power<0)){
                        throw new PropertyFailedException(this, "Radiator and cooler are on at same time ");
                    }
                    break;

                case 1: // human in room

                    if((!room.thermalRadiator.isOn) && room.passivePump.power<=0){
                        triple.state=2;
                        triple.transition="RadiatorOff";
                    }
                    else if( room.electricCooler.isOn || room.passivePump.power<0){
                        throw new PropertyFailedException(this, "Radiator and cooler are on at same time ");
                    }
                    break;
                case 2 : //no human in room

                    if(room.thermalRadiator.isOn || room.passivePump.power>0){
                        triple.state=1;
                        triple.transition="radiatorOn";
                    }
                    else if (room.electricCooler.isOn || room.passivePump.power<0){
                        triple.state=3;
                        triple.transition="coolerOn";
                    }
                    if((room.thermalRadiator.isOn || room.passivePump.power>0) && (room.electricCooler.isOn || room.passivePump.power<0)){
                        throw new PropertyFailedException(this, "Radiator and cooler are on at same time ");
                    }
                    break;
                case 3 :
                    if((!room.electricCooler.isOn) && room.passivePump.power>=0){
                        triple.state= 2;
                        triple.transition="coolerOff";
                    }
                    else if(room.thermalRadiator.isOn){
                        throw new PropertyFailedException(this, "Radiator and cooler are on at same time ");
                    }
                    break;

                default:
                    System.out.println("Error Property 4 default state");
                    break;
            }
        }
        return 0;
    }
    public String toString(){
        return "Property4";
    }
}

class Triple {
    Integer state;
    String transition;
    Integer step;

    public Triple(Integer sta, String tr, Integer ste) {
        state = sta;
        transition = tr;
        step = ste;
    }
}
