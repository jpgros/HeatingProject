public class Room {
    String name;
    double initialTemperature;
    double temperature;
    double previousTemperature;
    double volume;
    double surfaceExterior =10.0; //square meters
    double wallConductivity= 0.06;
    double isolationLevel;
    double wallSurface;
    double energyLoss;
    double heatingResistance;
    ThermalRadiator thermalRadiator;
    ElectricCooler electricCooler;

    TemperatureDevice passivePump; // energy efficiency already calculated
    public Room(String n, double initT, double temp, double v, double iL, ThermalRadiator tr, ElectricCooler ec){ // living room constructor
        initialTemperature= initT;
        temperature=temp;
        previousTemperature=temp;
        volume=v;
        isolationLevel=iL;
        heatingResistance=volume*1200; //masse air(1.2) *volume * capacite calorifique air(1000)
        thermalRadiator=tr;
        name=n;
        electricCooler=ec;
    }
    public Room(String n, double initT, double temp, double v, double iL, ThermalRadiator tr, TemperatureDevice pp){ // chamber constructor
        initialTemperature= initT;
        temperature=temp;
        previousTemperature=temp;
        volume=v;
        isolationLevel=iL;
        heatingResistance=volume*1200; //masse air(1.2) *volume * capacite calorifique air(1000)
        thermalRadiator=tr;
        passivePump = pp;
        name=n;
    }

    /**
     * Change radiator from on to off or from off to on
     * update initialTemperature to actual temperature
     */
    public void switchRadiator(){
        System.out.println("assigning "+ temperature);

        initialTemperature=temperature;
    }

    /**
     * calculates energy loss with external air
     * @return
     */
    void setEnergyLost(double externalTemperature){
        energyLoss = isolationLevel*wallSurface*(Math.abs(temperature-externalTemperature));
    }

    public double getInitialTemperature() {
        return initialTemperature;
    }

    public void setInitialTemperature(double initialTemperature) {
        this.initialTemperature = initialTemperature;
    }

    public double getTemperature() {
        return temperature;
    }

    public void setTemperature(double temperature) {
        this.temperature = temperature;
    }

    public double getVolume() {
        return volume;
    }

    public double getSurfaceExterior() {
        return surfaceExterior;
    }

    public double getWallConductivity() {
        return wallConductivity;
    }
}
