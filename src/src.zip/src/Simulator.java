public class Simulator {
    double coeffConvexionAir =10.0;
    double calorificCapacity = 1184;
    double k1,k2,k3;
    double solarAccEnergy=0.0;
    double time=0.0;
    double isolationCoeff = 5.3;
    public Simulator(){

    }

    public double calculateNewTemperature(double stepNb, double timeStep, double externalTemperature,Room room){
       /* System.out.println(livingRoomRadiator.power/livingRoom.heatingResistance);
        System.out.println( livingRoom.initialTemperature);
        System.out.println(stepNb*timeStep);*/

        double delta;
        if(room.thermalRadiator.isOn && room.electricCooler.isOn) System.out.println("radiator and cooler are on !");
        if(room.thermalRadiator.isOn) { // heating on
            delta=((room.thermalRadiator.power+ room.passivePump.power + termalTransfert(timeStep, externalTemperature, room)) * timeStep) / room.heatingResistance;
        }
        else if(room.electricCooler.isOn){ // cooler on
            delta=((room.electricCooler.power+ room.passivePump.power + termalTransfert(timeStep, externalTemperature, room)) * timeStep) / room.heatingResistance;
        }
        else{ // no device on
            delta= ( room.passivePump.power + (termalTransfert(timeStep, externalTemperature, room)) * timeStep) / room.heatingResistance;
        }

        //System.out.println("delta "+delta);
        room.previousTemperature= room.temperature;
        room.temperature +=delta;
        System.out.println("house temp is " + room.temperature);
        return room.temperature;
                //(stepNb*timeStep+ livingRoom.initialTemperature)*(livingRoomRadiator.power/livingRoom.heatingResistance);
    }

    public double termalTransfert(double timeStep, double externalTemperature, Room room){
        double d = isolationCoeff*room.surfaceExterior*(externalTemperature-room.temperature);
        //System.out.println("thermal " +d);
        return d;
    }
    public void addSolarEnergy(int nbSolarPanels, Weather weather){
        solarAccEnergy+= nbSolarPanels*GlobalVariables.solarPannelPower*weather.efficiency;
    }

        /*
        updateK1(); updateK2(); updateK3();
        double temperature = 1/(k1+k2)*((k1*livingRoomRadiator.heatingTemperature+k2*externalTemperature)-Math.exp(-(k1+k2)/k3*time+Math.log(k1*livingRoomRadiator.getHeatingTemperature()+k2*externalTemperature-(k1+k2)*livingRoom.getInitialTemperature())));
        time+=timeStep;
        double tmp=k1*livingRoomRadiator.getHeatingTemperature()+k2*externalTemperature-(k1+k2)*283.15;
        System.out.println("normal " + tmp + " ln " + Math.log(tmp));
        tmp=k1*livingRoomRadiator.getHeatingTemperature()+k2*externalTemperature-(k1+k2)*321.01;
        System.out.println("normal " + tmp + " ln " + Math.log(tmp));
        livingRoom.setTemperature(temperature);
        return temperature;
    }

    public void updateK1(){
        double temperatureLivingRoom = livingRoom.getTemperature();
        k1 = coeffConvexionAir*livingRoomRadiator.getSurface();

    }
    public void updateK2(){
       k2= 1/( 2/(coeffConvexionAir*livingRoom.getSurfaceExterior())+(livingRoom.wallThickness/(livingRoom.getWallConductivity()*livingRoom.surfaceExterior)));
    }

    public void updateK3(){
        k3=livingRoom.getVolume()*calorificCapacity;
    }*/
}
