public class TemperatureDevice {
    double energyConsumption;
    double power;
    boolean isOn;

    public TemperatureDevice(double ec, double p, boolean on){
        energyConsumption=ec;
        power=p;
        isOn=on;
    }

    public double getEnergyConsumption() {
        return energyConsumption;
    }
}
