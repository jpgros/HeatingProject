public class ThermalRadiator extends TemperatureDevice {

    public ThermalRadiator(double energyCons,double power, boolean on){
        super(energyCons, power,on);
    }
}
