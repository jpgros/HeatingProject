public enum Weather {
    RAIN(0.0), SUNNY(1.0), CLOUDY(0.3);
    final double efficiency;
    Weather(double eff){
        efficiency=eff;
    }
}